
-- --------------------------------------------------------

--
-- Estrutura para tabela `patrimonys_historys`
--

CREATE TABLE `patrimonys_historys` (
  `id` int(11) NOT NULL,
  `patrimony_id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `product_id` int(11) UNSIGNED NOT NULL,
  `unit_id` int(11) UNSIGNED DEFAULT NULL,
  `movement_id` int(11) UNSIGNED NOT NULL DEFAULT 1,
  `part_number` text NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `file_terms` text DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'actived' COMMENT 'actived, disabled',
  `patrimony_id_1` int(11) DEFAULT NULL,
  `patrimony_id_2` int(11) DEFAULT NULL,
  `observations` text DEFAULT NULL,
  `login_created` varchar(7) DEFAULT NULL,
  `created_history` timestamp NOT NULL DEFAULT current_timestamp(),
  `login_updated` varchar(7) NOT NULL DEFAULT 'sistema',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
