
-- --------------------------------------------------------

--
-- Estrutura para tabela `contactsnew`
--

CREATE TABLE `contactsnew` (
  `id` int(3) NOT NULL,
  `sector_name` varchar(23) DEFAULT NULL,
  `collaborator` varchar(37) DEFAULT NULL,
  `ramal` int(4) DEFAULT NULL,
  `status` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
