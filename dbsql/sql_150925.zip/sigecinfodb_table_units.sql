
-- --------------------------------------------------------

--
-- Estrutura para tabela `units`
--

CREATE TABLE `units` (
  `id` int(11) UNSIGNED NOT NULL,
  `unit_name` varchar(40) DEFAULT NULL,
  `description` varchar(75) DEFAULT NULL,
  `adress` varchar(74) DEFAULT NULL,
  `zip` varchar(9) DEFAULT NULL,
  `photo` varchar(34) DEFAULT NULL,
  `url` varchar(84) DEFAULT NULL,
  `it_professional` varchar(36) DEFAULT NULL,
  `fixed_phone` varchar(8) DEFAULT NULL,
  `cell_phone` varchar(9) DEFAULT NULL,
  `email` varchar(41) DEFAULT NULL,
  `status` varchar(8) DEFAULT 'actived',
  `login_created` varchar(7) NOT NULL DEFAULT 'sistema',
  `created_at` varchar(16) DEFAULT NULL,
  `login_updated` varchar(7) NOT NULL DEFAULT 'sistema',
  `updated_at` varchar(16) DEFAULT NULL,
  `observations` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Despejando dados para a tabela `units`
--

INSERT INTO `units` (`id`, `unit_name`, `description`, `adress`, `zip`, `photo`, `url`, `it_professional`, `fixed_phone`, `cell_phone`, `email`, `status`, `login_created`, `created_at`, `login_updated`, `updated_at`, `observations`) VALUES
(1, 'Tucuruvi', 'Congregação Cristã no Brasil - Tucuruvi', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'actived', 'sistema', NULL, 'sistema', NULL, NULL);
