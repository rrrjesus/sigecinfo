
-- --------------------------------------------------------

--
-- Estrutura para tabela `contracts`
--

CREATE TABLE `contracts` (
  `id` int(11) UNSIGNED NOT NULL,
  `sei_process` varchar(25) NOT NULL,
  `contract_name` text NOT NULL,
  `manager_id` int(11) UNSIGNED NOT NULL,
  `inspector_id` int(11) UNSIGNED NOT NULL,
  `deputy_inspector_id` int(11) UNSIGNED NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'actived' COMMENT 'actived, disabled',
  `description` text DEFAULT NULL,
  `observations` text DEFAULT NULL,
  `login_created` varchar(7) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `login_updated` varchar(7) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
