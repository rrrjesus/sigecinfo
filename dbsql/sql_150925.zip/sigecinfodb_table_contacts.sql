
-- --------------------------------------------------------

--
-- Estrutura para tabela `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) UNSIGNED NOT NULL,
  `unit_id` int(11) UNSIGNED NOT NULL DEFAULT 22,
  `contact_name` text DEFAULT NULL,
  `ramal` int(4) DEFAULT NULL,
  `status` varchar(8) DEFAULT 'actived' COMMENT 'actived, disabled',
  `login_created` varchar(7) DEFAULT NULL,
  `created_at` varchar(19) DEFAULT NULL,
  `login_updated` varchar(7) DEFAULT NULL,
  `updated_at` varchar(19) DEFAULT NULL,
  `login_deleted` varchar(7) DEFAULT NULL,
  `deleted_at` varchar(19) DEFAULT NULL,
  `sector_name_at` varchar(23) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
