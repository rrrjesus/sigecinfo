
-- --------------------------------------------------------

--
-- Estrutura para tabela `signatures`
--

CREATE TABLE `signatures` (
  `id` int(10) NOT NULL,
  `first_name` varchar(31) DEFAULT NULL,
  `last_name` varchar(60) DEFAULT NULL,
  `email` varchar(58) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
