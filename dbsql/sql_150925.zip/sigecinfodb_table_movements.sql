
-- --------------------------------------------------------

--
-- Estrutura para tabela `movements`
--

CREATE TABLE `movements` (
  `id` int(11) UNSIGNED NOT NULL,
  `movement_name` varchar(50) NOT NULL,
  `login_created` varchar(7) NOT NULL DEFAULT 'sistema',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
