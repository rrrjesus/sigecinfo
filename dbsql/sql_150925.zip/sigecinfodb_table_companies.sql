
-- --------------------------------------------------------

--
-- Estrutura para tabela `companies`
--

CREATE TABLE `companies` (
  `id` int(11) UNSIGNED NOT NULL,
  `company_name` text NOT NULL,
  `description` text NOT NULL,
  `site` text NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'actived' COMMENT 'actived, disabled',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `login_created` varchar(7) NOT NULL,
  `login_updated` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
